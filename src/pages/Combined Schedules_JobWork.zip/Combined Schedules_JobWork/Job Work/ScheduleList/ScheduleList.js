import React from 'react'

export default function ScheduleList() {
  return (
    <div>ScheduleList</div>
  )
}
